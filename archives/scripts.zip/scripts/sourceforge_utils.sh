#!/bin/bash

project_home_local="${SOURCEFORGE_REP}"
echo "Sync SourceForge ... Dist"

expire_time=0
cur_time=$( date "+1%H%M" )
SOURCEFORGE_PERIOD_getstored=$( date "+%Y%m%d" )
#cur_time="0001"
echo " current ... time :  ${cur_time}"
let "sourceforge_shell_time = sourceforge_shell_time +0"
let "sourceforge_shell_time_expire = sourceforge_shell_time_expire +0"
let "sourceforge_shell_time_expire_date = sourceforge_shell_time_expire_date +0"
let "sourceforge_shell_time_expire_max = sourceforge_shell_time_expire_max +0"

let "SOURCEFORGE_PERIOD_getstored = SOURCEFORGE_PERIOD_getstored + 0"

    time_modulo=0
    expire_modulo=0
sourceforge_shell_time=${cur_time}
sourceforge_shell_time_date=${SOURCEFORGE_PERIOD_getstored}
# ####################### # ####################### # ####################### # #######################
# ####################### # ####################### # ####################### # #######################

function set_furturetime_expire(){
echo "Setting future time expire ..."

sourceforge_shell_time_expire_date=${SOURCEFORGE_PERIOD_getstored}

sourceforge_shell_time_expire=${cur_time}

let "sourceforge_shell_time_expire = sourceforge_shell_time_expire +0"
let "time_modulo =  (sourceforge_shell_time_expire_max % 60)"

expire_modulo=${sourceforge_shell_time_expire:3:2}
expire_modulo_add=0

let "expire_modulo =  (expire_modulo +0)"
let "expire_modulo_add =  (time_modulo + expire_modulo )"

if [ ${expire_modulo_add} -gt 59 ]; then
let " expire_modulo_add =     (expire_modulo_add - 59) +100"
fi

let "sourceforge_shell_time_expire = sourceforge_shell_time_expire - expire_modulo "

echo " do reset ... time : ${sourceforge_shell_time_expire} : ${cur_time} : ${time_modulo} : ${expire_modulo_add}"
let "sourceforge_shell_time_expire =  sourceforge_shell_time_expire + ( ( ( (sourceforge_shell_time_expire_max - time_modulo ) / 60 )*100) +expire_modulo_add)"

echo " resetted ... time : ${sourceforge_shell_time_expire} : ${sourceforge_shell_time_expire_max}"

# ## setup date and time informations
sourceforge_shell_time=${cur_time}
sourceforge_shell_time_expire_date=${SOURCEFORGE_PERIOD_getstored}


# ## finaly we fix the time left
expire_time=${sourceforge_shell_time_expire_max}

# ## adjust to next day
if [ ${sourceforge_shell_time_expire} -gt 12359 ]; then
    let "sourceforge_shell_time_expire= sourceforge_shell_time_expire - 2359 "
    let "sourceforge_shell_time_expire_date = sourceforge_shell_time_expire_date +1"
fi

}

function get_expire_timeleft(){
echo "Getting time expire ..."

let "sourceforge_shell_time_expire = sourceforge_shell_time_expire +0"
let "time_modulo =  (sourceforge_shell_time_expire_max % 60)"
# ################ eval minutes
time_modulo="1${cur_time:3:2}"
time_expire_modulo="1${sourceforge_shell_time_expire:3:2}"

let "time_modulo =  time_modulo - 0"
let "time_expire_modulo =  time_expire_modulo + 0"


expire_modulo=0
hour_expire_modulo=0
let " expire_modulo= (time_expire_modulo - time_modulo) "

if [ ${expire_modulo} -lt 0 ]; then
let " expire_modulo= (-expire_modulo) "
fi

# ################ eval minutes
let "hour_expire_modulo= (sourceforge_shell_time_expire - time_expire_modulo) - ( cur_time - time_modulo)"

if [ ${hour_expire_modulo} -lt 0 ]; then
let " hour_expire_modulo= (-hour_expire_modulo) "
fi
let " hour_expire_modulo= ((hour_expire_modulo/100) * 60) "
 # ## finaly we fix the time left
let "expire_time_minute = ( (hour_expire_modulo ) + expire_modulo ) "

# expire_time_minute=${expire_time}
echo " expire_modulo : ${hour_expire_modulo} : ${expire_modulo} : ${expire_time_minute}"
}

# ####################### # ####################### # ####################### # #######################
# ####################### # ####################### # ####################### # #######################

 # ## day expire 22 -- > > current anything up ; time
 # ## day expire 22 -- > > current 23 ; next day all expired
if [  ${SOURCEFORGE_PERIOD_getstored} -gt  ${sourceforge_shell_time_expire_date} ]; then
    # call function to set new futur expire time
    set_furturetime_expire
    # set immediate expire
    expire_time=0
else
# ## time left :: like expire 15h - - > > current 16h
# ## day expire 22 -- > > current 22 ; day is the same all expired
    if [ ${cur_time} -gt ${sourceforge_shell_time_expire} ] && [   ${sourceforge_shell_time_expire_date} -eq ${SOURCEFORGE_PERIOD_getstored} ]; then

        # Reset to new time
        # call function to set expire time
        # ## set_furturetime_expire
        # set immediate expire
        expire_time=0
    else
# ## day expire 22 -- > > current 22 ; time
# ## time left :: like expire 15h - - > > current 23h
# ## time left :: like expire 23h - - > > current 01h ; before day
        echo " Session Valid"
        # ## call function to get expire time
        get_expire_timeleft
    fi
    echo " Session close at ${sourceforge_shell_time_expire_date} : ${expire_time}"
fi

expire_time=${expire_time_minute}
let " expire_time = expire_time +0"
echo "Session Should exipre at ${sourceforge_shell_time_expire_date} : ${sourceforge_shell_time_expire} : ${expire_time} : ${expire_time_minute}"
 # cat "${REPO_STATUS}"

if [ ${expire_time} -lt 2 ]; then

ssh -2 this_genose,mcosmcudvr@shell.sourceforge.net create
# ## && ssh -2 this_genose,mcosmcudvr@shell.sourceforge.net
# Reset to new time
# call function to set expire time
set_furturetime_expire

fi
echo "SourceForge Sync Repo "
    rsync -valkpoxirz --delete-during --exclude=".DS_*" "${SOURCEFORGE_REP}/" this_genose@shell.sourceforge.net:/home/frs/project/

echo " Sourceforge save local config ... ${REPO_STATUS}"
sed -i -- "s;\(sourceforge_shell_time_expire_date\)=\(.*\);\1=${sourceforge_shell_time_expire_date};g"  "${REPO_STATUS}"
sed -i -- "s;\(sourceforge_shell_time_expire\)=\(.*\);\1=${sourceforge_shell_time_expire};g"  "${REPO_STATUS}"
sed -i -- "s;\(sourceforge_shell_time\)=\(.*\);\1=${sourceforge_shell_time};g"  "${REPO_STATUS}"
sed -i -- "s;\(sourceforge_shell_time_date\)=\(.*\);\1=${sourceforge_shell_time_date};g"  "${REPO_STATUS}"
sed -i -- "s;\(sourceforge_errors\)=\(.*\);\1=${sourceforge_errors};g"  "${REPO_STATUS}"
sed -i -- "s;\(sourceforge_last_date\)=\(.*\);\1=${SOURCEFORGE_PERIOD_getstored};g"  "${REPO_STATUS}"

# cd /home/frs/project/mcosmcudvr/Gybs\ Aeron\ Ride

# ln -s archives/release_notes/README-$( date +%MY ).txt README.txt
