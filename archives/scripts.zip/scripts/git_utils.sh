#!/bin/bash


cd "${GITHUB_REP}"
GIT_PERIOD_BEGIN=$( date "+%b 1 %Y" )
GIT_PERIOD_NOW=$( date "+%b %d %Y" )
GIT_PERIOD_NOW_day=$( date "+%d" )



GIT_PERIOD_NOW=$( date "+%b %d %Y" )

GIT_PERIOD_STORED=${git_last_date}
GIT_PERIOD_getstored=$( date "+%Y%m%d" )

GIT_PERIOD_STORED_month=${GIT_PERIOD_STORED:0:6}
GIT_PERIOD_getstored_month=${GIT_PERIOD_getstored:0:6}

GIT_PERIOD_NOW_dayrelaease=$( date "+%d-%b-%Y" )
# ########## ###########
# ########## ###########
echo " Commit to Git ... from ${GITHUB_REP} date : ${GIT_PERIOD_NOW} : ${GIT_PERIOD_BEGIN} "
# ########## ###########
# ########## ###########
# git_monthly_build_count=$( git rev-list --count HEAD --since="${GIT_PERIOD_BEGIN}"  --before="${GIT_PERIOD_NOW}" )
dayingit=${GIT_PERIOD_NOW_day}
let "dayingit = dayingit +1"
daysin_date_prev=$( date "+%b ${dayingit} %Y" )
let "dayingit = dayingit -1"
# ########## ###########
# ########## ###########
# recount all releases
# ########## ###########

let "git_errors= git_errors +0"
#if [ ${git_errors} -gt 0 ]; then


# ########## ###########
daysin_date="${GIT_PERIOD_NOW}"
git_monthly_build_count=0

while [ ${dayingit} -gt 0 ] ; do

    git_count=$( git rev-list --count HEAD --since="${daysin_date}"  --before="${daysin_date_prev}" )

    let "git_count = git_count+0"
# ## echo " Git stat ${dayingit} : ${daysin_date} : ${git_count}"
    if [ ${git_count} -gt 0 ]; then
        # ## count montly release group by day
        # ## only released days are counted
        let  "git_monthly_build_count = git_monthly_build_count +1"
    fi
    # ########## ###########
    daysin_date_prev="${daysin_date}"
    # ########## ###########
    let "dayingit= dayingit -1"
    daysin_date=$( date "+%b ${dayingit} %Y" )
    # ########## ###########
done
# ########## ###########
# ########## ###########
    echo " Revealed Monthly Git : ${git_monthly_build_count}"
# ########## ###########
# fi
# ########## ###########
# ########## ###########

dayingit=${GIT_PERIOD_NOW_day}
let "dayingit = dayingit +1"
daysin_date_prev=$( date "+%b ${dayingit} %Y" )
let "dayingit = dayingit -1"

# ## use futur date
echo git rev-list --count HEAD --since=\"${GIT_PERIOD_BEGIN}\"  --before=\"${daysin_date_prev}\"

git_dayly_build_count=$( git rev-list --count HEAD --since="${GIT_PERIOD_NOW}"  --before="${daysin_date_prev}" )

# ## echo git rev-list --count HEAD --since=\"${GIT_PERIOD_NOW}\"  --before=\"${GIT_PERIOD_NOW}\"

# ########## ###########
# ########## ###########
let "GIT_PERIOD_getstored=GIT_PERIOD_getstored+0"
let "GIT_PERIOD_STORED=GIT_PERIOD_STORED+0"

# next day so add its a new release day ...
if [ ! ${GIT_PERIOD_STORED_month} -eq ${GIT_PERIOD_getstored_month} ]; then
        echo " Diff Month date Reset ...."
# ## automaticly reset  from git_dayly_build_count=0
# ## automaticly reset  from git_monthly_build_count=1

else
    echo " Diff date count ...."
    let "git_dayly_build_count= git_dayly_build_count +1"
fi

GIT_PERIOD_STORED=${GIT_PERIOD_getstored}

# ########## ###########
# ########## ###########
let "git_monthly_build_count= git_monthly_build_count+0"
if [ ${git_monthly_build_count} -eq 0 ]; then
    let "git_monthly_build_count= git_monthly_build_count+1"
fi
# ########## ###########
# ########## ###########


#let "git_dayly_build_count= git_dayly_build_count+0"
#if [ ${git_dayly_build_count} -gt 0 ]; then
#    let "git_dayly_build_count= git_dayly_build_count+1"
#fi
dayly_build_count=".${git_dayly_build_count}"
# ########## ###########
# ########## ###########
# ##ls "${GITHUB_REP}"
echo " Git add ..."
file_link_path=$( find "${GITHUB_REP}" -type l -maxdepth 2 -exec  readlink {} \; -exec echo ".alias:" \;  | sed \
-e "s;\(.*\)\(archives\/.*\);\2;g" \
 &&  ls -l "${GITHUB_REP}" | awk '{ if(length($9)>2){print $9} }'  | sed  -e "s;\(.*\);\1:;g"
)
 
file_link_path=$( echo ${file_link_path[@]} | tr ":" "\\n" | sed  -e "s;\(.*\);\"\1\";g" -e "s;\"\ \(.*\);\"\1;g" -e "s;\(.*\)\ \";\1\";g"  -e "s;\"\";;g" -e "s;\";::;g" -e "s; ;++;g")

# ## -e "s; \";\";g" -e "s; ;\\\ ;g"

echo " Add files for indexing : "
#
echo ${file_link_path[@]} | tr "::" "\\n"

cd "${GITHUB_REP}"
#
for git_infile in $( echo ${file_link_path} | sed -e "s;::;\";g" | tr "::" "\\n" ) ; do
git_infile=$( echo ${git_infile} | sed -e "s;++; ;g" -e "s;\";;g" )
echo " Git add : ${git_infile}"

ret_git=$( echo "git add '"${git_infile}"' 2>&1 " | bash )

ret_val=$?
let "ret_val = ret_val+0"
let "git_errors= git_errors+ret_val"
    if [ ${ret_val} -gt 0 ]; then

        "${dialog}"  --timeout 10 	--title "Information "    --msgbox "Git Errors ($ret_val) : add index (${git_infile}) ... \n reason  : ${ret_git} "  20 120
        exit 1
    else
        git_errors=0
    fi
done
#
#$( find "${GITHUB_REP}" -type f )
# git push
git_commit_message=" ${_stage_APP_brand_branch_str} - ${RELEASE_DATE_NOW} Updates #${git_monthly_build_count}${dayly_build_count} ${GIT_PERIOD_NOW_dayrelaease} - ${PROJECT_NAME} - Build : ${buildNumber}"
echo "${git_commit_message}"
# exit 1
# git commit -a -m "${git_commit_message}"
ret_val=$?
let "ret_val = ret_val+0"
let "git_errors= git_errors+ret_val"
if [ ${ret_val} -gt 0 ]; then
    "${dialog}"  --timeout 5 	--title "Information "    --msgbox "Git Errors : commit ...  "  20 80

fi
echo " GIT Push ..."

# git push origin master
# $( basename "${GITHUB_REP}" )
false
ret_val=$?
let "ret_val = ret_val+0"
let "git_errors= git_errors+ret_val"
if [ ${ret_val} -gt 0 ]; then
    "${dialog}"  --timeout 5 	--title "Information "    --msgbox "Git Errors : push ...  "  20 80
    exit 1
fi

# ########## ###########
# ########## ###########
echo " GIT save local config ... ${REPO_STATUS}"

# cat "${REPO_STATUS}"
sed -i -- "s;\(git_m.*\)=\(.*\);\1=${git_monthly_build_count};g"  "${REPO_STATUS}"
sed -i -- "s;\(git_d.*\)=\(.*\);\1=${git_dayly_build_count};g"  "${REPO_STATUS}"
sed -i -- "s;\(git_last_.*\)=\(.*\);\1=${GIT_PERIOD_STORED};g"  "${REPO_STATUS}"
sed -i -- "s;\(git_error.*\)=\(.*\);\1=${git_errors};g"  "${REPO_STATUS}"


echo " GIT done ..."

