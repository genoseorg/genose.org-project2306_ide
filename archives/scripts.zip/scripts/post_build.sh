#!/bin/bash
p_dir_project=$(echo ${PROJECT_DIR} | tr " " "_" )
# ## "$HOME/Desktop/gybs.plist"
# INFOPLIST_FILE="Info.plist"

env_vars_script="${p_dir_project}/scripts/env_pch_vars.sh"

touch "${env_vars_script}"
chmod 755 "${env_vars_script}"

cat ${p_dir_project}/sources/CoreDefs/*.*h | grep -i '#define ' | grep -i "@" | grep -v 'NSLog' | grep -v '\\' | grep -v '//'| grep -v '\['| sed "s;#define ;export##;g" |  sed "s; @;=;g" |  sed "s;##; ;g"  | sed 's,\ *=,=,g' > "${env_vars_script}"
# ##| awk '{print $1$2}'
# ## */
echo "# ######### " >> "${env_vars_script}"
printenv | sed -e "s;\";;g" | sed -e "s;\(.*\)=\(.*\);export \1=\"\2\";g" >> "${env_vars_script}"
# ## printenv  >> "${env_vars_script}"
source "${env_vars_script}"

SDKROOT=$( echo ${SDKROOT} || echo ${DEVELOPER_SDK_DIR} )

# ## echo "Building Target :: ${_APP_Name_str}"

# ## /bin/echo "Building PLIST ..."
# ##/bin/echo -n "PLIST PATH ::  ${p_dir_project}/${INFOPLIST_FILE}"
# ##/bin/echo -n "APP Vers ::  ${_APP_vers_str}"
# ##/bin/echo -n "API Vers ::  ${_API_vers_str}"

INFOPLIST_EXT="${TARGET_BUILD_DIR}/${INFOPLIST_PATH}"
buildNumber=$(/usr/libexec/PlistBuddy -c "Print CFBundleVersion" "${p_dir_project}/${INFOPLIST_FILE}")
# let "buildNumber = buildNumber +1"
# ## /bin/echo -n "APP Build ::  ${buildNumber}"
# ## PLISTCMD="Set :CFBundleVersion $(git rev-list --all|wc -l)"
# ## echo -n "$INFOPLIST_EXT" | xargs -0 /usr/libexec/PlistBuddy -c "$PLISTCMD"

/usr/libexec/PlistBuddy -c "Set :CFBundleVersion $buildNumber" "$INFOPLIST_FILE"
# ##  /usr/libexec/PlistBuddy -c "Set :CFBundleVersion $buildNumber" "${p_dir_project}/${INFOPLIST_FILE}"
/usr/libexec/PlistBuddy -c "Set :_API_vers_str ${_API_vers_str}" "$INFOPLIST_FILE"

# ## NSHumanReadableCopyright
## echo -ne "::${_APP_vers_str_b}::"
# ## sed -e "s;__MyCompanyName__;${__WEBSITE_ADRESS_NAME} ${_API_Name_str};g" "${p_dir_project}/${INFOPLIST_FILE}"
# ## sed -e "s;_APP_vers_str;build $buildNumber;g" "${p_dir_project}/English.lproj/InfoPlist.strings"

DATE_NOW=`date +%Y`
RELEASE_DATE_NOW=`date +%m%Y`

/usr/libexec/PlistBuddy -c "Set :NSHumanReadableCopyright 2006-$DATE_NOW ${__COMPANY_NAME__} ${_APP_vers_str}" "$INFOPLIST_FILE"

/usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString ${_APP_vers_str} Build.${buildNumber} ${_API_vers_str} " "$INFOPLIST_FILE"
# ## /usr/libexec/PlistBuddy -c "Set :NSHumanReadableCopyright 0.1a" "${p_dir_project}/${INFOPLIST_FILE}"


/usr/libexec/PlistBuddy -c "Set :_APP_vers_str_b ${_APP_vers_str_b}" "$INFOPLIST_FILE"

# ## /usr/libexec/PlistBuddy -c "Set :_APP_vers_str_b ${_APP_vers_str_b}" "${p_dir_project}/${INFOPLIST_FILE}"

/usr/libexec/PlistBuddy -c "Set :_APP_vers_str ${_APP_vers_str}" "$INFOPLIST_FILE"
# ## /usr/libexec/PlistBuddy -c "Set :_APP_vers_str {_APP_vers_str}" "${p_dir_project}/${INFOPLIST_FILE}"


# ## /usr/libexec/PlistBuddy -c "Set :_2306_run_number $buildNumber" "$INFOPLIST_FILE"
echo "SDK : ${SDKROOT}"
if [ ! -e "${SDKROOT}/usr/include/libxml2" ]; then
echo "No XML :: ${SDKROOT}/usr/include/libxml2"
exit -1
# ## else
# ## echo "XML :: LibXML2 found ... "

fi
REPO_STATUS="${p_dir_project}/scripts/repo_status.inc.sh"
source "${REPO_STATUS}"
#sed -i -- "s;\(git_m.*\)=\(.*\);\1=${git_monthly_build_count};g"  "${REPO_STATUS}"

# > "${REPO_STATUS}"
# cat "${REPO_STATUS}"
# exit 1

# ################### # ################### # ################### # ################### # ###################
# ################### # ################### # ################### # ################### # ###################
cd "${TARGET_BUILD_DIR}/"

REALEASE_BUILD_DIR="${p_dir_project}/notes/release_notes/"

README_TXT="README.txt"

README_BUILD_TXT="${REALEASE_BUILD_DIR}/${README_TXT}"

REALEASE_README_BUILD_TXT="${REALEASE_BUILD_DIR}/README-${RELEASE_DATE_NOW}.txt"

RELEASE_NOTE_BUILD_TXT="${REALEASE_BUILD_DIR}/releasenote.txt"

RELEASE_BUILD_TXT="${REALEASE_BUILD_DIR}/releasenote.txt"
PACKED_APP="${_shell_APP_PRODUCT_NAME_PACKED}"
PACKED_APP_ZIP=$( echo "${_shell_APP_PRODUCT_NAME_PACKED}" | sed -e "s;.app;;g" )

GITHUB_REP="$HOME/Documents/github/genose.org-project2306_ide/"

SOURCEFORGE_REP="$HOME/Documents/sourceforge/mcosmcudvr/Gybs Aeron Ride/"

if [ ! -f "${REALEASE_README_BUILD_TXT}" ]; then
    touch "${REALEASE_README_BUILD_TXT}"
fi
echo " Build Release Notes ... ${README_BUILD_TXT}"
echo "" > "${README_BUILD_TXT}"
echo "# ############################## " >> "${README_BUILD_TXT}"
echo "# Project : ${_stage_APP_brand_branch_str} " >> "${README_BUILD_TXT}"
echo "# Build : ${buildNumber}" >> "${README_BUILD_TXT}"
echo "# Executable : ${CONTENTS_FOLDER_PATH}/(see. Your PLATFORM Dir )/${EXECUTABLE_NAME}" >> "${README_BUILD_TXT}"
avail_platform_dir=$( find "${BUILT_PRODUCTS_DIR}/${CONTENTS_FOLDER_PATH}/" -iname "${EXECUTABLE_NAME}" -type f -maxdepth 2 -exec dirname {} \; | xargs basename | sed -e "s;\\n;,\ ;g" )
echo "platform : ${avail_platform_dir} "
echo "# Availble Platform : ${avail_platform_dir}" >> "${README_BUILD_TXT}"
echo "# ############################## " >> "${README_BUILD_TXT}"
echo " " >> "${README_BUILD_TXT}"
cat "${RELEASE_NOTE_BUILD_TXT}" >> "${README_BUILD_TXT}"
echo " " >> "${README_BUILD_TXT}"
echo "# ############################## " >> "${README_BUILD_TXT}"
echo " " >> "${README_BUILD_TXT}"
find  "${REALEASE_BUILD_DIR}" -type f -iname "readme*"  -size +1 -print | tr "\ " "\\n" | sort | tail -n1 | xargs cat >> ${README_BUILD_TXT}


# ################### # ################### # ################### # ################### # ###################
# ################### # ################### # ################### # ################### # ###################

mkdir -p  "${SOURCEFORGE_REP}/archives/release_notes/"

# rsync -vapoxirz --delete-during "${REALEASE_BUILD_DIR}" "${README_BUILD_TXT}" "${GITHUB_REP}/archives/release_notes/"
# rsync -apoxirz --delete-during --exclude=".DS_*" "${REALEASE_BUILD_DIR}" "${SOURCEFORGE_REP}/archives/release_notes/"

# # cp -pv "${p_dir_project}/${INFOPLIST_FILE}" "${FULL_PRODUCT_NAME}.app"
# ls -la "${BUILT_PRODUCTS_DIR}/${FULL_PRODUCT_NAME}"

# ################### # ################### # ################### # ################### # ###################
# ################### # ################### # ################### # ################### # ###################

echo " Adding Release Notes ... to Application Bundle ${FULL_PRODUCT_NAME}"
# ## Copy Readme to App Bundle, so personne can say "i don t have the legal notice or License NOTES" ...
cp -v "${README_BUILD_TXT}" "${README_TXT}"
cp -v "${README_TXT}" "${FULL_PRODUCT_NAME}/"

# ################### # ################### # ################### # ################### # ###################
# ################### # ################### # ################### # ################### # ###################

cp -v "${RELEASE_NOTE_BUILD_TXT}" "${FULL_PRODUCT_NAME}/"
cp -v "${RELEASE_NOTE_BUILD_TXT}" "${CONTENTS_FOLDER_PATH}/"

# ################### # ################### # ################### # ################### # ###################
# ################### # ################### # ################### # ################### # ###################

echo " Compress to sourceforge on ${TARGET_BUILD_DIR}/${PACKED_APP} to ${GITHUB_REP} "

# cp -pv "${p_dir_project}/${INFOPLIST_FILE}" "${GITHUB_REP}"

# ################### # ################### # ################### # ################### # ###################
# ################### # ################### # ################### # ################### # ###################

cd "${SOURCEFORGE_REP}"

echo " Compress to repository on ${TARGET_BUILD_DIR}/${PACKED_APP} to " $(pwd) "/archives/${PACKED_APP_ZIP} "


# cp -pv "${README_BUILD_TXT}" "${SOURCEFORGE_REP}/archives/release_notes/"

ln -sfn  "./archives/release_notes/${README_TXT}" "./${README_TXT}"

# ## mv "${SOURCEFORGE_REP}/${PACKED_APP}"* "${SOURCEFORGE_REP}/archives/"

# zip -r "${PACKED_APP_ZIP}.zip" "${FULL_PRODUCT_NAME}"  "${README_TXT}" 2>/dev/null
#cp -v "${PACKED_APP_ZIP}.zip" "${SOURCEFORGE_REP}/archives/${PACKED_APP_ZIP}.zip"

if [ ! -e "${SOURCEFORGE_REP}/${PACKED_APP_ZIP}.zip" ]; then
echo " rebuild symlink ... "
    find "${SOURCEFORGE_REP}" -name "${PROJECT_NAME}*" -type l -maxdepth 2 -exec rm -v {} \;

  ln -sfnv "./archives/${PACKED_APP_ZIP}.zip" "./${PACKED_APP_ZIP}.zip"
fi
echo " Rsync dir To GIT dir  .... "

rsync -aplokxirz --delete-during --exclude=".DS_*" --exclude=".git*" "${SOURCEFORGE_REP}" "${GITHUB_REP}"


# ################### # ################### # ################### # ################### # ###################
# ################### # ################### # ################### # ################### # ###################
if [ "${CONFIGURATION}" == "Default" ]; then

cd "${p_dir_project}/scripts/"
echo "" > /tmp/install_box_xcode.tmp
chmod 755 /tmp/install_box_xcode.tmp

PATH=$PATH:/opt/local/bin/
dialog="/opt/local/bin/xdialog"

cat > /tmp/install_box_xcode.tmp <<EOF
#!/bin/bash
if [ "$CONFIGURATION" == "Debug" ]; then
# increment build number
echo " Configuration DEbug ...."
fi
"${dialog}" --title "$CONFIGURATION : Publish for Target ${PACKED_APP_ZIP} ?" \
--fill \
--ok-label "Deploy ${PACKED_APP_ZIP} ...."  \
--cancel-label "Not Now" \
--yesno " Get Ready To deploy App to : \\n\
\\n\
- git \\n\
\\n\
- Sourceforge " 20 120

EOF

# dailog_result_Deploy=$( bash /tmp/install_box_xcode.tmp 2>&1  && echo $?  && echo "cc"   ||    echo $? && echo "vv"    )

switch_case_Deploy=$( echo ${dailog_result_Deploy} | awk '{print $1}' )
#
switch_case_Deploy=1
# ## echo " Deploy :: ${dailog_result_Deploy}  :: $switch_case_Deploy"

# ## void value

let "switch_case_Deploy= switch_case_Deploy+0"

# echo " Deploy :: as int ::$switch_case_Deploy"
case  $switch_case_Deploy in
0)
echo " Yes chosen. Deploy"
cd "${p_dir_project}/scripts/"
# source ./git_utils.sh
cd "${p_dir_project}/scripts/"
# source ./sourceforge_utils.sh
cd "${p_dir_project}/scripts/"
;;

*)
echo " Box close chosen. No chosen. Deploy "
# "${dialog}"  --timeout 5 	--title "Information "    --msgbox "Installation Cancelled ...  "  20 80

;;
esac


fi

