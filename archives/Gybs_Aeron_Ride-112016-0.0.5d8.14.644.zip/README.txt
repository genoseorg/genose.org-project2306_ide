
# ############################## 
# Project : project2306_ide 
# Build : 4411
# Executable : Gybs_Aeron_Ride.app/Contents/(see. Your PLATFORM Dir )/Gybs_Aeron_Ride
# Availble Platform : haiku
beos
linux
macos
# ############################## 
 
Currently Only MacOS is Present, PreAlpha means not Ready to use, Application is provided Without Strict Garantee, License not OSI.

All others platform Windows, Linux, HaikuOS STILL under TEST, Dummy "Hello world" is provided instead


 
# ############################## 
 
# Mise à jour & Correctifs 092016 Septembre (App.V0.0.5 DevRelease 8.15.65/build3628):

-- Support All MacOSX from 10.4.6 PPC to 10.10, (You read right, it still runs on PowerMac PPC (G4/G5) and 10.4 back compatible in minds)
    --> MacOSX PPC (G4/G5), (MacOS Tiger 10.4.6 to 10.6)
    --> MacOSX Intel (32/64 Bits) fully tested (10.4.6 to 10.10)
    --> GUI still based in French
    --> Still Universal Build, Back to Business From Build 3800

**************************
Core & Internal Class Improvements
**************************

-- Improved 2306Core Capatibities
    --> More C99 Compliants
    --> More suitable implementation
    --> Lighter implementation, more flexible
    --> NSException improved / POSIX Signals Handling and customs;
    --> NSError protocol-like behaviour and customs
    --> NSAlert Mechanism and customs
    --> More Corrections / Replacement API Deprecated
    --> More Class Binding from GUI

    --> Drag and drop implementation

    --> Stylized / Personnalized NSAlert

    --> First API Release, Yeaaaah !!

-- Integrated Logging & Window console logs
    --> This is back for the past ...
    --> Easiest Logging call
    --> Terminal Bash-alike

-- Support multi screens
    --> Automatic sticky screen corner
    --> UP to 4 screens or more ...
    --> Screens Geometry and arrangements friendly (1*4 ; 2*2 ; 1*3 +1 )

-- More Custom Window improvement
    --> Windowing system
    --> Window position relative to Main screen
    --> Window Style Mutation
    --> Window NSEvent Improved

**************************
Miscellanous
**************************

-- Resolved Humain Readable informations
-- Resolved More Memory Leaks against new implementation

**************************
GUI Improvements
**************************

-- StartupScreen improvements
    --> Drawning & stylizing
    --> More Icons, MacOS9 Loading Style

**************************

-- TextEditor improvements
    --> Add Color Text
    --> Add Legacy Theme Toolbar
    --> Drag and Drop Text
    --> Text Links

**************************
Common Class
**************************

-- NSString improvement
    --> Revolved some Memory issues
    --> Still Clickable & Themable

**************************

-- NSimage improvement
    --> Deprecated Drawning issues
    --> Deprecated Caching issues

**************************

-- NSMenu got a Lot More Styles & possibility
    --> Maintain Icons in Menus over Systems Versions
    --> Dialog Like inside Menus




